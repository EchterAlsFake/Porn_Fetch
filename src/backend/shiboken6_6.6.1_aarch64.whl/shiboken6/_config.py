shiboken_library_soversion = str(6.6)

version = "6.6.1"
version_info = (6, 6, 1, "", "")

__build_date__ = '2024-02-06T16:47:50+00:00'
__build_commit_date__ = '2023-11-27T13:25:49+00:00'
__build_commit_hash__ = '3a63e748fc193656d293a56fc30b6453b0d5508b'
__build_commit_hash_described__ = 'v6.6.1'

__setup_py_package_version__ = '6.6.1'

